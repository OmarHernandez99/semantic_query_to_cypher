#!/bin/sh
make_logo.sh
latexmk